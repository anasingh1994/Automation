package com.hcap.stackoverflow.automation.stepdefinition;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
/**
 * @author AnamikaSingh
 *
 */
public class BrowserStackSD {

	WebDriver driver;
	
	@When ("^User is at stackoverflow page$")
	public void user_is_page() {
		
		System.setProperty("webdriver.chrome.driver", "/Users/anasingh/Downloads/chromedriver"); 
		driver = new ChromeDriver();
		driver.get("https://stackoverflow.com/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		String actual = driver.getTitle();
		String expected = "Stack Overflow - Where Developers Learn, Share, & Build Careers";
		Assert.assertEquals(actual, expected);
		System.out.println("Title is: " + actual);
		
		
	}
		
	
	
	@And("^User click on Browse Questions section$")
	    public void user_click_on__Browse_Questions_Section() {
	     WebElement BrowseQuestions = driver.findElement(By.xpath("//a[@role='menuitem']"));
			Assert.assertEquals(BrowseQuestions.isDisplayed(), true);
			BrowseQuestions.click();
			System.out.println("User click on Browse Questions section.");
		    
		
	}
	
	
	@And("^User click on the Users link in the left section$") 
	public void click_on_link() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='nav-users']")));
		 element.click();

	    
	}

	@And("^User click on the Editors$") 
	public void click_on_editor() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Editors')]")));
		 element.click();
		 }

	
	@Then("^Verify Users list displayed and get the user name which has the max number of edits$") 
	public void list_displayed() 
	{
	
        List<WebElement> list_of_Users = driver.findElements(By.xpath("//*[@id='user-browser']/div/div/div[2]"));
		List<WebElement> list_of_Edits = driver.findElements(By.xpath("//*[@id='user-browser']/div[1]/div/div[3]"));
		
		//Use of HashMaop to store Users and Their edits(after conversion to Integer)
		String User_name;
		String Edits_count;
		int int_edits_count;
		HashMap<Integer, String> map_final_Output = new HashMap<Integer,String>();
		for(int i=0;i<list_of_Users.size();i++) {
			User_name = list_of_Users.get(i).getText();//Iterate and fetch the  user name
			Edits_count = list_of_Edits.get(i).getText();//Iterate and fetch edits count
			Edits_count = Edits_count.replaceAll("[^0-9]", "");//Replace anything will space other than numbers
			int_edits_count = Integer.parseInt(Edits_count);//Convert to Integer
			map_final_Output.put(int_edits_count,User_name);//Add product and price in HashMap
		}
		//Reporter.log("User Name and edits fetched from stackOverflow UI and saved in HashMap as:" + map_final_Output.toString() + "<br>",true);
 
		//Find the Highest and Lowest edits
		//One way is to fetch all values of the hashMap and then save it in the ArrayList
		//Then using Collections class in java, sort it. this we can easily get highest and lowest
		
		//Get all the keys from Hash Map
		Set<Integer> allEditsValue = map_final_Output.keySet();
		ArrayList<Integer> array_list_values_edit_count = new ArrayList<Integer>(allEditsValue);
		
		//Sort the edits in Array List using Collections class
		//this will sort in ascending order lowest at the top and highest at the bottom
		Collections.sort(array_list_values_edit_count);
		
		//Highest eddits count is
		int highCount_edits = array_list_values_edit_count.get(array_list_values_edit_count.size()-1);
		
		//Lowest edits count is 
		int lowCount_edits = array_list_values_edit_count.get(0);
		System.out.println("High edits count is: " + highCount_edits + " User name is: " + map_final_Output.get(highCount_edits));
		
		System.out.println("Low edits count is: " + lowCount_edits + " User name is: " + map_final_Output.get(lowCount_edits));
		
	
	
	
	}
		
		
	@Then("^User change second page to see the user list with edits$")
	public void Change_pagination() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		scrollUpToElement("//*[@title='Go to page 2'][1]");
		 WebElement pagination=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@title='Go to page 2'][1]")));
		 pagination.click();
	}
 
	

	
	protected void scrollUpToElement(final String xpath) {
		JavascriptExecutor js = (JavascriptExecutor) (driver);
		js.executeScript("arguments[0].scrollIntoView(true);", 
				driver.findElement(By.xpath(xpath)));
	}
	
	@Then("^close the browser$")
	public void close_browser() {
		driver.close();
	}
	


	}


